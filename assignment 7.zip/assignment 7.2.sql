USE Names;
-- Create a table  table
CREATE TABLE ORDERS (
    OrderID INT PRIMARY KEY,
    CustomerName VARCHAR(100)
);

-- INSERT VALUES ON THE ORDERS TABLE

INSERT INTO Orders (OrderID, CustomerName)
VALUES
(101, 'John Doe'),
(102, 'Jane Smith'),
(103, 'Emily Clark');
